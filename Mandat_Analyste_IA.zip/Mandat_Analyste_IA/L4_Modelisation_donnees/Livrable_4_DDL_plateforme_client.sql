-- ============================================================================
-- Livrable 4 — Script DDL : plateforme de données client unifiée (golden record)
-- Périmètre phase 1 : Gestion de patrimoine (iAGPP, Investia, iA Clarington,
-- Patrimoine Richardson). Mandat simulé — projet portfolio analyse d'affaires TI.
-- SGBD cible : PostgreSQL 15+. Modèle : voir ERD Lucidchart (Livrable 4) et
-- dictionnaire de données (Livrable_4_Dictionnaire_donnees_iA.xlsx).
-- Convention : snake_case, UUID en clé, aucun NAS en clair (RG-08).
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS plateforme_client;
SET search_path TO plateforme_client;

-- ---------------------------------------------------------------------------
-- Référentiels de structure
-- ---------------------------------------------------------------------------
CREATE TABLE reseau_distribution (
    reseau_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code_reseau        VARCHAR(20)  NOT NULL UNIQUE,          -- IAGPP, INVESTIA, CLARINGTON, RICHARDSON
    nom_reseau         VARCHAR(100) NOT NULL,
    entite_juridique   VARCHAR(100) NOT NULL
);

CREATE TABLE systeme_source (
    systeme_source_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code_systeme       VARCHAR(20)  NOT NULL UNIQUE,
    nom_systeme        VARCHAR(100) NOT NULL,
    entite_juridique   VARCHAR(100) NOT NULL,
    type_systeme       VARCHAR(30)  NOT NULL CHECK (type_systeme IN ('CRM','BACK_OFFICE','COURTAGE','FONDS')),
    statut             VARCHAR(20)  NOT NULL DEFAULT 'ACTIF'
                       CHECK (statut IN ('ACTIF','EN_MIGRATION','DECOMMISSIONNE'))  -- suivi du bénéfice H11
);

-- ---------------------------------------------------------------------------
-- Golden record client et correspondances sources
-- ---------------------------------------------------------------------------
CREATE TABLE client (
    client_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_client           VARCHAR(20) NOT NULL CHECK (type_client IN ('PARTICULIER','ENTREPRISE','FIDUCIE','SUCCESSION')),
    nom                   VARCHAR(100) NOT NULL,
    prenom                VARCHAR(100),
    date_naissance        DATE CHECK (date_naissance >= DATE '1900-01-01'),
    nas_hash              CHAR(64),                            -- SHA-256 salé, jamais de NAS en clair (RG-08)
    statut_kyc            VARCHAR(20) NOT NULL DEFAULT 'A_VERIFIER'
                          CHECK (statut_kyc IN ('A_VERIFIER','VALIDE','EXPIRE','REFUSE')),
    score_risque          SMALLINT CHECK (score_risque BETWEEN 0 AND 100),
    statut_golden_record  VARCHAR(20) NOT NULL DEFAULT 'ACTIF'
                          CHECK (statut_golden_record IN ('ACTIF','FUSIONNE','SUSPENDU','ARCHIVE')),  -- RG-03
    date_creation         TIMESTAMP NOT NULL DEFAULT now(),
    date_maj              TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_client_nas_hash ON client (nas_hash) WHERE nas_hash IS NOT NULL;   -- rapprochement déterministe RG-01
CREATE INDEX idx_client_nom_naissance ON client (nom, date_naissance);              -- rapprochement probabiliste RG-02

CREATE TABLE identifiant_source (
    xref_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id            UUID NOT NULL REFERENCES client (client_id),
    systeme_source_id    UUID NOT NULL REFERENCES systeme_source (systeme_source_id),
    identifiant_externe  VARCHAR(60) NOT NULL,
    statut_rapprochement VARCHAR(20) NOT NULL CHECK (statut_rapprochement IN ('AUTO','CONFIRME','A_REVOIR','REJETE')),
    score_confiance      DECIMAL(5,2) NOT NULL CHECK (score_confiance BETWEEN 0 AND 100),  -- seuils RG-02
    date_rapprochement   TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT uq_id_par_systeme UNIQUE (systeme_source_id, identifiant_externe)     -- un id source = un golden record
);

-- ---------------------------------------------------------------------------
-- Attributs multi-valués et historisés du client
-- ---------------------------------------------------------------------------
CREATE TABLE adresse (
    adresse_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id         UUID NOT NULL REFERENCES client (client_id),
    type_adresse      VARCHAR(20) NOT NULL CHECK (type_adresse IN ('DOMICILE','POSTALE','FISCALE','TRAVAIL')),
    ligne1            VARCHAR(150) NOT NULL,
    ville             VARCHAR(80)  NOT NULL,
    province          CHAR(2)      NOT NULL,
    code_postal       VARCHAR(10)  NOT NULL,
    pays              CHAR(2)      NOT NULL DEFAULT 'CA',
    valide_depuis     DATE NOT NULL,
    valide_jusqua     DATE,                                    -- NULL = adresse courante (RG-10)
    source_survivance VARCHAR(20) NOT NULL,                    -- traçabilité RG-04
    CHECK (valide_jusqua IS NULL OR valide_jusqua > valide_depuis)
);
CREATE INDEX idx_adresse_client ON adresse (client_id);

CREATE TABLE coordonnee (
    coordonnee_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id              UUID NOT NULL REFERENCES client (client_id),
    type_coordonnee        VARCHAR(20) NOT NULL CHECK (type_coordonnee IN ('COURRIEL','TEL_MOBILE','TEL_FIXE')),
    valeur                 VARCHAR(150) NOT NULL,              -- normalisée RG-06
    consentement_marketing BOOLEAN NOT NULL DEFAULT FALSE,     -- RG-07
    date_maj               TIMESTAMP NOT NULL DEFAULT now()
);
CREATE INDEX idx_coordonnee_client ON coordonnee (client_id);

-- ---------------------------------------------------------------------------
-- Distribution : réseaux, conseillers, relations
-- ---------------------------------------------------------------------------
CREATE TABLE conseiller (
    conseiller_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reseau_id        UUID NOT NULL REFERENCES reseau_distribution (reseau_id),
    code_repartiteur VARCHAR(20) NOT NULL,
    nom              VARCHAR(100) NOT NULL,
    prenom           VARCHAR(100) NOT NULL,
    statut           VARCHAR(20) NOT NULL DEFAULT 'ACTIF' CHECK (statut IN ('ACTIF','INACTIF','PARTI')),
    date_debut       DATE,                                     -- suivi rétention (RF Capital, H15)
    CONSTRAINT uq_repartiteur_reseau UNIQUE (reseau_id, code_repartiteur)
);

CREATE TABLE relation_client_conseiller (
    relation_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id     UUID NOT NULL REFERENCES client (client_id),
    conseiller_id UUID NOT NULL REFERENCES conseiller (conseiller_id),
    role_relation VARCHAR(20) NOT NULL CHECK (role_relation IN ('PRINCIPAL','SECONDAIRE','EQUIPE')),
    date_debut    DATE NOT NULL,
    date_fin      DATE,                                        -- historisation RG-10
    CHECK (date_fin IS NULL OR date_fin >= date_debut)
);
-- RG-09 : une seule relation PRINCIPAL active par client et par réseau (index partiel via jointure applicative;
-- contrôle renforcé côté service, le réseau étant porté par le conseiller)
CREATE INDEX idx_relation_client ON relation_client_conseiller (client_id) WHERE date_fin IS NULL;

-- ---------------------------------------------------------------------------
-- Comptes (réplique de référence, non transactionnelle)
-- ---------------------------------------------------------------------------
CREATE TABLE compte (
    compte_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id         UUID NOT NULL REFERENCES client (client_id),
    reseau_id         UUID NOT NULL REFERENCES reseau_distribution (reseau_id),
    systeme_source_id UUID NOT NULL REFERENCES systeme_source (systeme_source_id),
    numero_compte     VARCHAR(30) NOT NULL,
    type_compte       VARCHAR(30) NOT NULL CHECK (type_compte IN ('CELI','REER','FERR','CRI','NON_ENREGISTRE','REEE')),
    devise            CHAR(3) NOT NULL DEFAULT 'CAD',
    statut            VARCHAR(20) NOT NULL DEFAULT 'OUVERT' CHECK (statut IN ('OUVERT','GELE','FERME')),
    date_ouverture    DATE NOT NULL,
    CONSTRAINT uq_compte_systeme UNIQUE (systeme_source_id, numero_compte)
);
CREATE INDEX idx_compte_client ON compte (client_id);

-- ---------------------------------------------------------------------------
-- Conformité : KYC/LBA et consentements (Loi 25)
-- ---------------------------------------------------------------------------
CREATE TABLE dossier_kyc (
    kyc_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES client (client_id),
    niveau_verification VARCHAR(20) NOT NULL CHECK (niveau_verification IN ('SIMPLIFIE','STANDARD','RENFORCE')),
    resultat_lba        VARCHAR(20) NOT NULL CHECK (resultat_lba IN ('CONFORME','EXCEPTION','REFUSE')),
    date_verification   DATE NOT NULL,
    date_expiration     DATE NOT NULL,                         -- RG-05 : réutilisation inter-entités si non expiré
    reference_documents VARCHAR(200),                          -- référence GED, aucun document stocké ici
    CHECK (date_expiration > date_verification)
);
CREATE INDEX idx_kyc_client ON dossier_kyc (client_id, date_expiration DESC);

CREATE TABLE consentement (
    consentement_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id        UUID NOT NULL REFERENCES client (client_id),
    type_consentement VARCHAR(40) NOT NULL CHECK (type_consentement IN ('PARTAGE_INTER_ENTITES','MARKETING','PROFILAGE')),
    statut           VARCHAR(20) NOT NULL CHECK (statut IN ('ACCORDE','REVOQUE','EXPIRE')),
    canal            VARCHAR(20) NOT NULL CHECK (canal IN ('PORTAIL','CONSEILLER','TELEPHONE','PAPIER')),
    date_octroi      TIMESTAMP NOT NULL,
    date_revocation  TIMESTAMP,                                -- traçabilité Loi 25 (RG-07)
    CHECK (date_revocation IS NULL OR date_revocation >= date_octroi)
);
CREATE INDEX idx_consentement_client ON consentement (client_id, type_consentement);

-- ---------------------------------------------------------------------------
-- Ménages (regroupements pour la vue 360° et les ventes croisées, H13)
-- ---------------------------------------------------------------------------
CREATE TABLE menage (
    menage_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nom_menage    VARCHAR(120) NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE membre_menage (
    membre_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    menage_id   UUID NOT NULL REFERENCES menage (menage_id),
    client_id   UUID NOT NULL REFERENCES client (client_id),
    role_menage VARCHAR(20) NOT NULL CHECK (role_menage IN ('CHEF','CONJOINT','ENFANT','AUTRE')),
    date_debut  DATE NOT NULL,
    CONSTRAINT uq_membre UNIQUE (menage_id, client_id)
);

-- ---------------------------------------------------------------------------
-- Vue d'exemple : vue client 360° filtrée par consentement (RG-07)
-- Démontre la règle « pas de partage inter-entités sans consentement ACCORDE ».
-- ---------------------------------------------------------------------------
CREATE VIEW v_client_360 AS
SELECT c.client_id,
       c.nom,
       c.prenom,
       c.statut_kyc,
       COUNT(DISTINCT cp.compte_id)                        AS nb_comptes,
       COUNT(DISTINCT cp.reseau_id)                        AS nb_reseaux,     -- indicateur de ventes croisées (H13)
       MAX(k.date_expiration)                              AS kyc_expire_le
FROM client c
LEFT JOIN compte cp        ON cp.client_id = c.client_id
LEFT JOIN dossier_kyc k    ON k.client_id  = c.client_id
WHERE c.statut_golden_record = 'ACTIF'
  AND EXISTS (SELECT 1 FROM consentement s
              WHERE s.client_id = c.client_id
                AND s.type_consentement = 'PARTAGE_INTER_ENTITES'
                AND s.statut = 'ACCORDE')
GROUP BY c.client_id, c.nom, c.prenom, c.statut_kyc;
